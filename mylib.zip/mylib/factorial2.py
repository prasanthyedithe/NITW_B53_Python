#!/opt/conda/bin/python

def fact1(n):
  if 0 == n:
    return 1
  return n * fact1(n - 1)

if __name__ == '__main__':
    print(fact1(5))
else:
    print("The name of the module is ",__name__,"loaded")