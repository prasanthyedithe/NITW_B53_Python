#!/opt/conda/bin/python

def fact1(n):
  if 0 == n:
    return 1
  return n * fact1(n - 1)
