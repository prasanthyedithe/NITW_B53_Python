def getsum(dict1):
    for key in dict1.keys():
        sum = 0
        for value in dict1.get(key):
            sum += value
        print(key, ':', sum)

